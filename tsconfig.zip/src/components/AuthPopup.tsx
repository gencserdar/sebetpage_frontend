import { useState } from "react";

interface Props {
  mode: "login" | "register";
  onSubmit: (data: { email: string; password: string }) => void;
}
export default function AuthPopup({ mode, onSubmit }: Props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const title = mode === "login" ? "Log in to your account" : "Create an account";
  const cta   = mode === "login" ? "Log in" : "Create account";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ email, password });
  };

  return (
    <div className="flex flex-col md:flex-row bg-[#262339] text-white rounded-2xl overflow-hidden shadow-2xl w-full max-w-3xl">
      {/* LEFT – hero panel */}
      <div className="relative md:w-1/2 h-56 md:h-auto">
        <img
          src="/hero.jpg"           /* 1200×900 koyu görsel koy */
          alt="hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* Logo + caption */}
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative z-10 flex h-full flex-col justify-between p-6">
          <div className="text-2xl font-bold">SEBETPAGE</div>

          <div className="mb-6">
            <h3 className="text-lg leading-snug">
              Capturing Moments,<br />Creating Memories
            </h3>
            {/* slider dotları */}
            <div className="flex space-x-2 mt-4">
              <span className="w-4 h-0.5 bg-gray-600 rounded-sm" />
              <span className="w-4 h-0.5 bg-gray-600 rounded-sm" />
              <span className="w-4 h-0.5 bg-white rounded-sm" />
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT – form */}
      <div className="md:w-1/2 p-8">
        <h2 className="text-2xl font-bold mb-2">{title}</h2>

        {mode === "login" && (
          <p className="text-sm text-gray-400 mb-6">
            Don’t have an account?{" "}
            <a href="/register" className="underline">
              Sign up
            </a>
          </p>
        )}
        {mode === "register" && (
          <p className="text-sm text-gray-400 mb-6">
            Already have an account?{" "}
            <a href="/login" className="underline">
              Log in
            </a>
          </p>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-md bg-[#322f45] py-2 px-3 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <div className="relative">
            <input
              type="password"
              placeholder="Password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-md bg-[#322f45] py-2 px-3 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {/* göz ikonu isteğe bağlı */}
          </div>
          {mode === "register" && (
            <label className="flex items-center text-sm">
              <input type="checkbox" required className="mr-2 accent-indigo-500" />
              I agree to the&nbsp;
              <a href="#" className="underline">
                Terms &amp; Conditions
              </a>
            </label>
          )}

          <button
            type="submit"
            className="w-full py-2 rounded-md bg-indigo-500 hover:bg-indigo-600 transition font-medium"
          >
            {cta}
          </button>
        </form>

        {/* sosyal butonlar */}
        <div className="mt-8 space-y-3">
          <div className="relative flex items-center">
            <span className="flex-1 h-px bg-gray-600" />
            <span className="px-3 text-xs text-gray-400 uppercase">or {mode === "login" ? "log in" : "register"} with</span>
            <span className="flex-1 h-px bg-gray-600" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button className="border border-gray-600 rounded-md py-2 flex items-center justify-center space-x-2 hover:bg-white/5 transition">
              <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="" className="w-4" />
              <span className="text-sm">Google</span>
            </button>
            <button className="border border-gray-600 rounded-md py-2 flex items-center justify-center space-x-2 hover:bg-white/5 transition">
              <img src="https://www.svgrepo.com/show/452220/apple.svg" alt="" className="w-4 fill-white" />
              <span className="text-sm">Apple</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
