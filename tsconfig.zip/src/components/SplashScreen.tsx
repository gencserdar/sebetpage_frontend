import { motion } from "framer-motion";
import { useEffect } from "react";

export default function SplashScreen({ onFinish }: { onFinish: () => void }) {
}
