import { useState } from "react";

export default function LoginPopup({ onSubmit }: { onSubmit: (e:any)=>void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <form onSubmit={(e)=>{e.preventDefault();onSubmit({email,password});}} className="p-8 space-y-5">
      <h2 className="text-2xl font-bold text-center">Log in</h2>

      <input
        type="email"
        placeholder="Email"
        value={email}
        required
        onChange={(e) => setEmail(e.target.value)}
        className="w-full px-4 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-black"
      />

      <input
        type="password"
        placeholder="Password"
        value={password}
        required
        onChange={(e) => setPassword(e.target.value)}
        className="w-full px-4 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-black"
      />

      <button
        type="submit"
        className="w-full bg-black text-white py-2 rounded-md hover:bg-gray-800 transition"
      >
        Log in
      </button>
    </form>
  );
}
