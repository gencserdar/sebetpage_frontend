// src/App.tsx
import { useState } from "react";
import SplashScreen from "./components/SplashScreen";
import MainRouter from "./MainRouter";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <>

        <MainRouter />

    </>
  );
}
