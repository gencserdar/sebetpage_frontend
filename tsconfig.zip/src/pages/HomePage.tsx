import { useState } from "react";
import Modal from "../components/Modal";
import AuthPopup from "../components/AuthPopup";

export default function HomePage() {
  const [open, setOpen] = useState(false);

  const handleAuth = (data:{email:string;password:string})=>{
    // axios.post("/api/auth/login", data).then(...)
    console.log(data);
    setOpen(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#1c1a29]">
      <button onClick={() => setOpen(true)} className="px-6 py-3 bg-indigo-500 text-white rounded-lg">
        Open Login
      </button>

      <Modal open={open} onClose={() => setOpen(false)}>
        <AuthPopup mode="login" onSubmit={handleAuth} />
      </Modal>
    </div>
  );
}
