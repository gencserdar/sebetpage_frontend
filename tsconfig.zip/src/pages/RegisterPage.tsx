export default function RegisterPage() {
  return <h2 style={{ textAlign: "center", marginTop: "100px" }}>RegisterPage Page</h2>;
}
