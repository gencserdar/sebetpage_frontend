export default function ResetPasswordPage() {
  return <h2 style={{ textAlign: "center", marginTop: "100px" }}>Reset Password Page</h2>;
}
